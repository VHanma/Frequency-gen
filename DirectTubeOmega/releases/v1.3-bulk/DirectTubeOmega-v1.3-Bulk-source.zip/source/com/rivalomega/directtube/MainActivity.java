package com.rivalomega.directtube;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int PINK = Color.rgb(241, 62, 105);
    private static final int INK = Color.rgb(8, 8, 10);
    private static final int BODY = Color.rgb(91, 98, 108);
    private static final int SOFT = Color.rgb(247, 247, 248);
    private static final int BORDER = Color.rgb(226, 227, 230);
    private static final int SAVE_DOC = 5001;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private ScrollView pageScroll;
    private LinearLayout page;
    private EditText input;
    private EditText languages;
    private EditText search;
    private TextView status;
    private TextView output;
    private TextView resultTitle;
    private TextView resultMeta;
    private LinearLayout resultSection;
    private ScrollView outputScroll;
    private Button fetch;
    private Button nextMatch;
    private CheckBox timestamps;

    private LinearLayout bulkSection;
    private EditText bulkInput;
    private TextView bulkStatus;
    private Button bulkStart;
    private Button bulkStop;
    private Button bulkCopyAll;
    private Button bulkExportAll;
    private ListView bulkList;
    private ArrayAdapter<String> bulkAdapter;
    private final ArrayList<BulkItem> bulkItems = new ArrayList<>();
    private final ArrayList<String> bulkLabels = new ArrayList<>();
    private volatile boolean bulkStopRequested = false;
    private boolean bulkRunning = false;
    private int bulkSkippedInvalid = 0;

    private YouTubeTranscriptClient.Result lastResult;
    private YouTubeTranscriptClient.Probe currentProbe;
    private int searchOffset = -1;
    private String pendingSaveText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        styleSystemBars();
        buildUi();
        acceptIncomingIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        acceptIncomingIntent(intent);
    }

    private void styleSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(Color.WHITE);
        window.setNavigationBarColor(Color.WHITE);
        window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    private void buildUi() {
        pageScroll = new ScrollView(this);
        pageScroll.setFillViewport(true);
        pageScroll.setBackgroundColor(Color.WHITE);
        pageScroll.setClipToPadding(false);

        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.WHITE);
        page.setPadding(dp(28), dp(22), dp(28), dp(42));
        pageScroll.addView(page, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        buildTopBar();
        addSpace(98);
        buildHero();
        addSpace(28);
        buildInputAndPrimaryAction();
        addSpace(22);
        buildSecondaryActions();
        addSpace(18);
        buildBulkSection();
        addSpace(18);

        status = new TextView(this);
        status.setText("Ready.");
        status.setTextColor(Color.rgb(128, 131, 138));
        status.setTextSize(13);
        status.setVisibility(View.GONE);
        status.setPadding(dp(2), 0, dp(2), 0);
        page.addView(status, fullWrap());

        buildResultSection();
        setContentView(pageScroll);
    }

    private void buildTopBar() {
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView menu = new TextView(this);
        menu.setText("☰");
        menu.setTextColor(INK);
        menu.setTextSize(37);
        menu.setGravity(Gravity.CENTER);
        menu.setPadding(0, 0, 0, dp(4));
        menu.setOnClickListener(v -> showMainMenu());
        top.addView(menu, new LinearLayout.LayoutParams(dp(64), dp(64)));

        TextView brand = new TextView(this);
        brand.setText("DirectTube Ω");
        brand.setTextColor(Color.rgb(160, 162, 168));
        brand.setTextSize(13);
        brand.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(64), 1f));

        page.addView(top, fullWrap());
    }

    private void buildHero() {
        TextView signal = new TextView(this);
        SpannableStringBuilder signalText = new SpannableStringBuilder("★★★★★  Direct YouTube caption extraction");
        signalText.setSpan(new ForegroundColorSpan(PINK), 0, 5,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        signalText.setSpan(new StyleSpan(Typeface.BOLD), 7, signalText.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        signal.setText(signalText);
        signal.setTextColor(INK);
        signal.setTextSize(16);
        signal.setGravity(Gravity.START);
        page.addView(signal, fullWrap());

        addSpace(42);

        TextView headline = new TextView(this);
        String line = "Turn YouTube Videos into\nTranscripts Instantly";
        SpannableStringBuilder h = new SpannableStringBuilder(line);
        int pinkStart = line.indexOf("Instantly");
        h.setSpan(new ForegroundColorSpan(PINK), pinkStart, line.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        h.setSpan(new StyleSpan(Typeface.BOLD), 0, line.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        headline.setText(h);
        headline.setTextColor(INK);
        headline.setTextSize(40);
        headline.setLineSpacing(dp(2), 1.04f);
        headline.setIncludeFontPadding(false);
        page.addView(headline, fullWrap());

        addSpace(44);

        TextView description = new TextView(this);
        description.setText("Easily convert a YouTube video to transcript, copy and download the generated transcript in one tap.");
        description.setTextColor(BODY);
        description.setTextSize(21);
        description.setLineSpacing(dp(7), 1.0f);
        description.setIncludeFontPadding(false);
        page.addView(description, fullWrap());
    }

    private void buildInputAndPrimaryAction() {
        input = new EditText(this);
        input.setHint("Paste your YouTube video link here");
        input.setHintTextColor(Color.rgb(125, 129, 138));
        input.setTextColor(INK);
        input.setTextSize(18);
        input.setSingleLine(true);
        input.setPadding(dp(26), 0, dp(20), 0);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setBackground(rounded(Color.WHITE, PINK, 1.7f, 12));
        page.addView(input, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(68)));

        addSpace(18);

        fetch = new Button(this);
        fetch.setText("Extract transcript");
        fetch.setTextColor(Color.WHITE);
        fetch.setTextSize(18);
        fetch.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        fetch.setAllCaps(false);
        fetch.setGravity(Gravity.CENTER);
        fetch.setPadding(dp(12), 0, dp(12), 0);
        fetch.setBackground(rounded(PINK, PINK, 0, 10));
        fetch.setOnClickListener(v -> fetchDefault());
        page.addView(fetch, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(64)));
    }

    private void buildSecondaryActions() {
        Button choose = softAction("Choose caption track", "›");
        choose.setOnClickListener(v -> chooseTrack());
        page.addView(choose, new LinearLayout.LayoutParams(dp(360), dp(58)));

        addSpace(12);

        Button history = softAction("Transcript history", "›");
        history.setOnClickListener(v -> showHistory());
        page.addView(history, new LinearLayout.LayoutParams(dp(360), dp(58)));

        addSpace(12);

        Button bulk = softAction("Bulk transcribe", "›");
        bulk.setOnClickListener(v -> showBulkSection());
        page.addView(bulk, new LinearLayout.LayoutParams(dp(360), dp(58)));
    }

    private void buildBulkSection() {
        bulkSection = new LinearLayout(this);
        bulkSection.setOrientation(LinearLayout.VERTICAL);
        bulkSection.setPadding(dp(18), dp(18), dp(18), dp(18));
        bulkSection.setBackground(rounded(Color.rgb(250, 250, 251), Color.rgb(235, 235, 238), 1f, 12));
        bulkSection.setVisibility(View.GONE);

        TextView heading = new TextView(this);
        heading.setText("Bulk transcribe");
        heading.setTextColor(INK);
        heading.setTextSize(24);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bulkSection.addView(heading, fullWrap());

        TextView desc = new TextView(this);
        desc.setText("Paste a whole wall of YouTube links or 11-character video IDs. DirectTube will process the entire list one by one with no app-side queue cap.");
        desc.setTextColor(BODY);
        desc.setTextSize(15);
        desc.setLineSpacing(dp(3), 1f);
        desc.setPadding(0, dp(8), 0, dp(14));
        bulkSection.addView(desc, fullWrap());

        bulkInput = new EditText(this);
        bulkInput.setHint("Paste links or IDs here, one per line or separated by spaces");
        bulkInput.setHintTextColor(Color.rgb(139, 142, 150));
        bulkInput.setTextColor(INK);
        bulkInput.setTextSize(15);
        bulkInput.setGravity(Gravity.TOP | Gravity.START);
        bulkInput.setMinLines(6);
        bulkInput.setMaxLines(12);
        bulkInput.setPadding(dp(16), dp(14), dp(16), dp(14));
        bulkInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        bulkInput.setBackground(rounded(Color.WHITE, BORDER, 1f, 10));
        bulkSection.addView(bulkInput, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(190)));

        View gap1 = new View(this);
        bulkSection.addView(gap1, new LinearLayout.LayoutParams(1, dp(14)));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER_VERTICAL);

        bulkStart = compactAction("Transcribe all");
        bulkStart.setTextColor(Color.WHITE);
        bulkStart.setBackground(rounded(PINK, PINK, 0, 10));
        bulkStart.setOnClickListener(v -> startBulk());
        controls.addView(bulkStart, new LinearLayout.LayoutParams(0, dp(50), 1f));

        addHorizontalSpace(controls, 10);
        bulkStop = compactAction("Stop");
        bulkStop.setEnabled(false);
        bulkStop.setAlpha(0.5f);
        bulkStop.setOnClickListener(v -> stopBulk());
        controls.addView(bulkStop, new LinearLayout.LayoutParams(dp(92), dp(50)));

        bulkSection.addView(controls, fullWrap());

        bulkStatus = new TextView(this);
        bulkStatus.setText("Paste your list, then tap Transcribe all.");
        bulkStatus.setTextColor(Color.rgb(120, 124, 133));
        bulkStatus.setTextSize(13);
        bulkStatus.setPadding(dp(2), dp(12), dp(2), dp(10));
        bulkSection.addView(bulkStatus, fullWrap());

        bulkList = new ListView(this);
        bulkList.setDividerHeight(dp(1));
        bulkList.setBackgroundColor(Color.WHITE);
        bulkAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, bulkLabels);
        bulkList.setAdapter(bulkAdapter);
        bulkList.setOnItemClickListener((parent, view, position, id) -> openBulkItem(position));
        bulkSection.addView(bulkList, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(320)));

        View gap2 = new View(this);
        bulkSection.addView(gap2, new LinearLayout.LayoutParams(1, dp(12)));

        LinearLayout batchActions = new LinearLayout(this);
        batchActions.setOrientation(LinearLayout.HORIZONTAL);

        bulkCopyAll = compactAction("Copy all");
        bulkCopyAll.setEnabled(false);
        bulkCopyAll.setAlpha(0.5f);
        bulkCopyAll.setOnClickListener(v -> copyBulkAll());
        batchActions.addView(bulkCopyAll, new LinearLayout.LayoutParams(0, dp(48), 1f));

        addHorizontalSpace(batchActions, 8);
        bulkExportAll = compactAction("Export all TXT");
        bulkExportAll.setEnabled(false);
        bulkExportAll.setAlpha(0.5f);
        bulkExportAll.setOnClickListener(v -> exportBulkAll());
        batchActions.addView(bulkExportAll, new LinearLayout.LayoutParams(0, dp(48), 1f));

        bulkSection.addView(batchActions, fullWrap());

        Button clearBulk = compactAction("Clear bulk queue");
        clearBulk.setOnClickListener(v -> clearBulkQueue());
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        clearLp.topMargin = dp(8);
        bulkSection.addView(clearBulk, clearLp);

        page.addView(bulkSection, fullWrap());
    }

    private void showBulkSection() {
        bulkSection.setVisibility(View.VISIBLE);
        bulkSection.post(() -> pageScroll.smoothScrollTo(0, bulkSection.getTop()));
    }

    private void startBulk() {
        if (bulkRunning) return;
        BulkParse parsed = parseBulkInput(bulkInput.getText().toString());
        if (parsed.urls.isEmpty()) {
            toast("Paste at least one YouTube link or video ID.");
            return;
        }

        bulkItems.clear();
        bulkLabels.clear();
        bulkSkippedInvalid = parsed.invalid;
        for (String url : parsed.urls) {
            BulkItem item = new BulkItem();
            item.url = url;
            item.videoId = YouTubeTranscriptClient.extractVideoId(url);
            item.state = "Queued";
            bulkItems.add(item);
            bulkLabels.add(bulkLabel(item, bulkItems.size() - 1));
        }
        bulkAdapter.notifyDataSetChanged();

        bulkStopRequested = false;
        bulkRunning = true;
        fetch.setEnabled(false);
        fetch.setAlpha(0.65f);
        bulkStart.setEnabled(false);
        bulkStart.setAlpha(0.65f);
        bulkStart.setText("Transcribing…");
        bulkStop.setEnabled(true);
        bulkStop.setAlpha(1f);
        setBulkActionsEnabled(false);
        updateBulkProgress(0, 0, 0, false);

        final String langs = languages.getText().toString().trim();
        executor.submit(() -> {
            int done = 0;
            int ok = 0;
            int failed = 0;
            for (int i = 0; i < bulkItems.size(); i++) {
                if (bulkStopRequested) break;
                BulkItem item = bulkItems.get(i);
                item.state = "Extracting";
                final int startIndex = i;
                final int startDone = done;
                final int startOk = ok;
                final int startFailed = failed;
                runOnUiThread(() -> {
                    updateBulkRow(startIndex);
                    updateBulkProgress(startDone, startOk, startFailed, false);
                });

                try {
                    YouTubeTranscriptClient.Result r = YouTubeTranscriptClient.fetch(item.url, langs);
                    item.result = r;
                    item.state = "Done";
                    TranscriptStore.save(this, r);
                    ok++;
                } catch (Exception e) {
                    item.error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                    item.state = "Failed";
                    failed++;
                }
                done++;

                final int endIndex = i;
                final int endDone = done;
                final int endOk = ok;
                final int endFailed = failed;
                runOnUiThread(() -> {
                    updateBulkRow(endIndex);
                    updateBulkProgress(endDone, endOk, endFailed, false);
                    setBulkActionsEnabled(endOk > 0);
                });
            }

            final int finalDone = done;
            final int finalOk = ok;
            final int finalFailed = failed;
            final boolean stopped = bulkStopRequested;
            runOnUiThread(() -> finishBulk(finalDone, finalOk, finalFailed, stopped));
        });
    }

    private void stopBulk() {
        if (!bulkRunning) return;
        bulkStopRequested = true;
        bulkStop.setEnabled(false);
        bulkStop.setAlpha(0.5f);
        bulkStatus.setText("Stopping after the current video finishes…");
    }

    private void finishBulk(int done, int ok, int failed, boolean stopped) {
        bulkRunning = false;
        bulkStopRequested = false;
        fetch.setEnabled(true);
        fetch.setAlpha(1f);
        bulkStart.setEnabled(true);
        bulkStart.setAlpha(1f);
        bulkStart.setText("Transcribe all");
        bulkStop.setEnabled(false);
        bulkStop.setAlpha(0.5f);
        setBulkActionsEnabled(ok > 0);
        updateBulkProgress(done, ok, failed, true);
        if (stopped) {
            bulkStatus.setText("Stopped • " + done + " processed • " + ok + " complete • " + failed + " failed"
                    + invalidSuffix());
        }
    }

    private void updateBulkProgress(int done, int ok, int failed, boolean finished) {
        int total = bulkItems.size();
        String prefix = finished ? "Finished" : "Processing";
        bulkStatus.setText(prefix + " • " + done + " / " + total + " processed • " + ok + " complete • " + failed + " failed"
                + invalidSuffix());
    }

    private String invalidSuffix() {
        return bulkSkippedInvalid > 0 ? " • " + bulkSkippedInvalid + " skipped" : "";
    }

    private void updateBulkRow(int index) {
        if (index < 0 || index >= bulkItems.size()) return;
        while (bulkLabels.size() < bulkItems.size()) bulkLabels.add("");
        bulkLabels.set(index, bulkLabel(bulkItems.get(index), index));
        bulkAdapter.notifyDataSetChanged();
    }

    private String bulkLabel(BulkItem item, int index) {
        String name = item.result != null ? safeTitle(item.result) : item.videoId;
        if (name == null || name.isEmpty()) name = "Video " + (index + 1);
        String second;
        if (item.result != null) {
            second = "Done • " + wordCount(item.result.plainText()) + " words • tap to open";
        } else if ("Failed".equals(item.state)) {
            String err = item.error == null ? "Unknown error" : item.error;
            if (err.length() > 90) err = err.substring(0, 90) + "…";
            second = "Failed • " + err;
        } else {
            second = item.state == null ? "Queued" : item.state;
        }
        return (index + 1) + ". " + name + "\n" + second;
    }

    private int wordCount(String text) {
        if (text == null) return 0;
        String t = text.trim();
        if (t.isEmpty()) return 0;
        return t.split("\\s+").length;
    }

    private void openBulkItem(int position) {
        if (position < 0 || position >= bulkItems.size()) return;
        BulkItem item = bulkItems.get(position);
        if (item.result == null) {
            if (item.error != null) toast("This item failed: " + item.error);
            else toast(item.state == null ? "Still queued." : item.state + ".");
            return;
        }
        input.setText("https://www.youtube.com/watch?v=" + item.result.videoId);
        acceptResult(null, item.result);
    }

    private void copyBulkAll() {
        String text = bulkCombinedText();
        if (text.isEmpty()) {
            toast("No completed bulk transcripts yet.");
            return;
        }
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("DirectTube bulk transcripts", text));
            toast("All completed transcripts copied.");
        } catch (Exception e) {
            toast("Copy failed. Use Export all TXT for very large batches.");
        }
    }

    private void exportBulkAll() {
        String text = bulkCombinedText();
        if (text.isEmpty()) {
            toast("No completed bulk transcripts yet.");
            return;
        }
        int count = bulkSuccessCount();
        saveDocument("DirectTubeOmega_bulk_" + count + "_transcripts.txt", "text/plain", text);
    }

    private String bulkCombinedText() {
        StringBuilder b = new StringBuilder();
        int n = 0;
        for (BulkItem item : bulkItems) {
            if (item.result == null) continue;
            n++;
            if (b.length() > 0) b.append("\n\n============================================================\n\n");
            b.append("# ").append(n).append(" • ").append(safeTitle(item.result)).append('\n');
            b.append("https://www.youtube.com/watch?v=").append(item.result.videoId).append('\n');
            b.append("Language: ").append(item.result.languageCode == null ? "" : item.result.languageCode).append("\n\n");
            b.append(item.result.plainText().trim());
        }
        return b.toString();
    }

    private int bulkSuccessCount() {
        int count = 0;
        for (BulkItem item : bulkItems) if (item.result != null) count++;
        return count;
    }

    private void setBulkActionsEnabled(boolean enabled) {
        bulkCopyAll.setEnabled(enabled);
        bulkCopyAll.setAlpha(enabled ? 1f : 0.5f);
        bulkExportAll.setEnabled(enabled);
        bulkExportAll.setAlpha(enabled ? 1f : 0.5f);
    }

    private void clearBulkQueue() {
        if (bulkRunning) {
            toast("Stop the bulk queue first.");
            return;
        }
        bulkItems.clear();
        bulkLabels.clear();
        bulkAdapter.notifyDataSetChanged();
        bulkInput.setText("");
        bulkSkippedInvalid = 0;
        setBulkActionsEnabled(false);
        bulkStatus.setText("Paste your list, then tap Transcribe all.");
    }

    private BulkParse parseBulkInput(String raw) {
        BulkParse out = new BulkParse();
        if (raw == null || raw.trim().isEmpty()) return out;
        String[] tokens = raw.split("[\\s,;]+");
        for (String token : tokens) {
            if (token == null) continue;
            String cleaned = cleanBulkToken(token);
            if (cleaned.isEmpty()) continue;
            String id = YouTubeTranscriptClient.extractVideoId(cleaned);
            if (id == null) {
                out.invalid++;
                continue;
            }
            out.urls.add("https://www.youtube.com/watch?v=" + id);
        }
        return out;
    }

    private String cleanBulkToken(String token) {
        String s = token.trim();
        while (!s.isEmpty() && "([{<\"'".indexOf(s.charAt(0)) >= 0) s = s.substring(1);
        while (!s.isEmpty() && ")]}>\"'.".indexOf(s.charAt(s.length() - 1)) >= 0) s = s.substring(0, s.length() - 1);
        return s;
    }

    private static final class BulkParse {
        final ArrayList<String> urls = new ArrayList<>();
        int invalid;
    }

    private static final class BulkItem {
        String url;
        String videoId;
        String state;
        String error;
        YouTubeTranscriptClient.Result result;
    }

    private void buildResultSection() {
        resultSection = new LinearLayout(this);
        resultSection.setOrientation(LinearLayout.VERTICAL);
        resultSection.setVisibility(View.GONE);
        resultSection.setPadding(0, dp(34), 0, 0);

        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(238, 238, 240));
        resultSection.addView(divider, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));

        addResultSpace(28);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        resultTitle = new TextView(this);
        resultTitle.setText("Transcript");
        resultTitle.setTextColor(INK);
        resultTitle.setTextSize(28);
        resultTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleRow.addView(resultTitle, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        timestamps = new CheckBox(this);
        timestamps.setText("Timestamps");
        timestamps.setTextColor(BODY);
        timestamps.setTextSize(14);
        timestamps.setChecked(true);
        timestamps.setButtonTintList(android.content.res.ColorStateList.valueOf(PINK));
        timestamps.setOnCheckedChangeListener((buttonView, isChecked) -> render());
        titleRow.addView(timestamps);
        resultSection.addView(titleRow, fullWrap());

        resultMeta = new TextView(this);
        resultMeta.setTextColor(Color.rgb(120, 124, 133));
        resultMeta.setTextSize(13);
        resultMeta.setPadding(0, dp(8), 0, dp(18));
        resultSection.addView(resultMeta, fullWrap());

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setGravity(Gravity.CENTER_VERTICAL);

        Button copy = compactAction("Copy");
        copy.setOnClickListener(v -> copyTranscript());
        tools.addView(copy, new LinearLayout.LayoutParams(0, dp(48), 1f));

        addHorizontalSpace(tools, 8);
        Button export = compactAction("Export");
        export.setOnClickListener(v -> showExport());
        tools.addView(export, new LinearLayout.LayoutParams(0, dp(48), 1f));

        addHorizontalSpace(tools, 8);
        Button share = compactAction("Share");
        share.setOnClickListener(v -> shareTranscript());
        tools.addView(share, new LinearLayout.LayoutParams(0, dp(48), 1f));

        resultSection.addView(tools, fullWrap());
        addResultSpace(14);

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);

        search = new EditText(this);
        search.setHint("Search transcript");
        search.setHintTextColor(Color.rgb(139, 142, 150));
        search.setTextColor(INK);
        search.setTextSize(16);
        search.setSingleLine(true);
        search.setPadding(dp(18), 0, dp(12), 0);
        search.setBackground(rounded(Color.WHITE, BORDER, 1f, 10));
        searchRow.addView(search, new LinearLayout.LayoutParams(0, dp(52), 1f));

        addHorizontalSpace(searchRow, 10);
        nextMatch = new Button(this);
        nextMatch.setText("Next");
        nextMatch.setTextColor(PINK);
        nextMatch.setTextSize(14);
        nextMatch.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        nextMatch.setAllCaps(false);
        nextMatch.setBackground(rounded(Color.rgb(255, 244, 247), Color.rgb(255, 211, 222), 1f, 10));
        nextMatch.setOnClickListener(v -> findNext());
        searchRow.addView(nextMatch, new LinearLayout.LayoutParams(dp(88), dp(52)));
        resultSection.addView(searchRow, fullWrap());

        addResultSpace(18);

        LinearLayout transcriptCard = new LinearLayout(this);
        transcriptCard.setOrientation(LinearLayout.VERTICAL);
        transcriptCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        transcriptCard.setBackground(rounded(Color.rgb(250, 250, 251), Color.rgb(235, 235, 238), 1f, 12));

        output = new TextView(this);
        output.setTextIsSelectable(true);
        output.setTextColor(Color.rgb(35, 37, 42));
        output.setLinkTextColor(PINK);
        output.setTextSize(16);
        output.setLineSpacing(dp(5), 1f);
        output.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());

        outputScroll = new ScrollView(this);
        outputScroll.setFillViewport(false);
        outputScroll.addView(output);
        transcriptCard.addView(outputScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(440)));
        resultSection.addView(transcriptCard, fullWrap());

        addResultSpace(14);
        Button video = compactAction("Open video");
        video.setOnClickListener(v -> openVideoAt(0));
        resultSection.addView(video, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50)));

        page.addView(resultSection, fullWrap());

        languages = new EditText(this);
        languages.setText("en");
        languages.setVisibility(View.GONE);
        page.addView(languages, new LinearLayout.LayoutParams(1, 1));
    }

    private void showMainMenu() {
        String[] items = lastResult == null
                ? new String[]{"Bulk transcribe", "Choose caption track", "Transcript history", "Language priority", "About"}
                : new String[]{"Bulk transcribe", "Choose caption track", "Transcript history", "Language priority", "Copy transcript", "Export", "Share", "Open video", "Clear", "About"};

        new AlertDialog.Builder(this)
                .setTitle("DirectTube Ω")
                .setItems(items, (dialog, which) -> {
                    String item = items[which];
                    if (item.startsWith("Bulk")) showBulkSection();
                    else if (item.startsWith("Choose")) chooseTrack();
                    else if (item.startsWith("Transcript history")) showHistory();
                    else if (item.startsWith("Language")) showLanguageDialog();
                    else if (item.startsWith("Copy")) copyTranscript();
                    else if (item.equals("Export")) showExport();
                    else if (item.equals("Share")) shareTranscript();
                    else if (item.startsWith("Open")) openVideoAt(0);
                    else if (item.equals("Clear")) clearScreen();
                    else showAbout();
                })
                .show();
    }

    private void showLanguageDialog() {
        final EditText field = new EditText(this);
        field.setHint("en, es, fr...");
        field.setText(languages.getText().toString());
        field.setSingleLine(true);
        int pad = dp(22);
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(pad, dp(4), pad, 0);
        wrap.addView(field, fullWrap());
        new AlertDialog.Builder(this)
                .setTitle("Language priority")
                .setView(wrap)
                .setPositiveButton("Save", (d, w) -> languages.setText(field.getText().toString().trim()))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle("DirectTube Ω")
                .setMessage("Single and bulk YouTube transcript extraction with full-transcript compatibility, fallback caption routes, search, timestamps, history and export.")
                .setPositiveButton("OK", null)
                .show();
    }

    private Button softAction(String label, String arrow) {
        Button b = new Button(this);
        b.setText(label + "    " + arrow);
        b.setTextColor(INK);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        b.setPadding(dp(28), 0, dp(22), 0);
        b.setBackground(rounded(SOFT, SOFT, 0, 10));
        return b;
    }

    private Button compactAction(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(INK);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setBackground(rounded(SOFT, BORDER, 1f, 10));
        return b;
    }

    private GradientDrawable rounded(int fill, int stroke, float strokeDp, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(Math.max(1, Math.round(dpFloat(strokeDp))), stroke);
        return d;
    }

    private void acceptIncomingIntent(Intent intent) {
        if (intent == null) return;
        String candidate = null;
        if (Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            candidate = intent.getStringExtra(Intent.EXTRA_TEXT);
        } else if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            candidate = intent.getDataString();
        }
        if (candidate != null) {
            BulkParse parsed = parseBulkInput(candidate);
            if (parsed.urls.size() > 1) {
                bulkInput.setText(candidate.trim());
                showBulkSection();
            } else if (YouTubeTranscriptClient.extractVideoId(candidate) != null) {
                input.setText(candidate.trim());
                fetchDefault();
            }
        }
    }

    private void fetchDefault() {
        String raw = input.getText().toString().trim();
        String langs = languages.getText().toString().trim();
        if (raw.isEmpty()) {
            toast("Paste or share a YouTube link.");
            return;
        }

        busy("Extracting full transcript…");
        executor.submit(() -> {
            try {
                YouTubeTranscriptClient.Result r = YouTubeTranscriptClient.fetch(raw, langs);
                runOnUiThread(() -> acceptResult(null, r));
            } catch (Exception e) {
                runOnUiThread(() -> fail(e));
            }
        });
    }

    private YouTubeTranscriptClient.Result fetchPreferredFromProbe(YouTubeTranscriptClient.Probe p, String preferred) throws Exception {
        String firstPref = "en";
        if (preferred != null && !preferred.trim().isEmpty()) {
            firstPref = preferred.trim().split("[,\\s]+")[0];
        }

        YouTubeTranscriptClient.Track manualExact = null;
        YouTubeTranscriptClient.Track autoExact = null;
        YouTubeTranscriptClient.Track english = null;
        YouTubeTranscriptClient.Track firstManual = null;
        YouTubeTranscriptClient.Track first = p.tracks.get(0);

        for (YouTubeTranscriptClient.Track t : p.tracks) {
            boolean match = t.languageCode.equalsIgnoreCase(firstPref)
                    || t.languageCode.toLowerCase(Locale.US).startsWith(firstPref.toLowerCase(Locale.US) + "-");
            if (match && !t.generated && manualExact == null) manualExact = t;
            if (match && t.generated && autoExact == null) autoExact = t;
            if (t.languageCode.toLowerCase(Locale.US).startsWith("en") && english == null) english = t;
            if (!t.generated && firstManual == null) firstManual = t;
        }

        YouTubeTranscriptClient.Track chosen = manualExact != null ? manualExact
                : autoExact != null ? autoExact
                : english != null ? english
                : firstManual != null ? firstManual : first;

        String translate = null;
        boolean requestedMatches = chosen.languageCode.equalsIgnoreCase(firstPref)
                || chosen.languageCode.toLowerCase(Locale.US).startsWith(firstPref.toLowerCase(Locale.US) + "-");
        if (!requestedMatches && chosen.translatable) translate = firstPref;

        return YouTubeTranscriptClient.fetchTrack(p, chosen, translate);
    }

    private void chooseTrack() {
        if (bulkRunning) {
            toast("Bulk queue is running.");
            return;
        }
        String raw = input.getText().toString().trim();
        if (raw.isEmpty() && currentProbe == null) {
            toast("Paste or share a YouTube link first.");
            return;
        }

        String currentId = YouTubeTranscriptClient.extractVideoId(raw);
        if (currentProbe != null && currentProbe.videoId.equals(currentId)) {
            showTrackDialog(currentProbe);
            return;
        }

        busy("Reading available caption tracks…");
        executor.submit(() -> {
            try {
                YouTubeTranscriptClient.Probe p = YouTubeTranscriptClient.probe(raw);
                runOnUiThread(() -> {
                    currentProbe = p;
                    setBusy(false);
                    showTrackDialog(p);
                });
            } catch (Exception e) {
                runOnUiThread(() -> fail(e));
            }
        });
    }

    private void showTrackDialog(YouTubeTranscriptClient.Probe p) {
        String[] labels = new String[p.tracks.size()];
        for (int i = 0; i < labels.length; i++) labels[i] = p.tracks.get(i).label();

        new AlertDialog.Builder(this)
                .setTitle("Caption track")
                .setItems(labels, (dialog, which) -> {
                    YouTubeTranscriptClient.Track chosen = p.tracks.get(which);
                    String requested = languages.getText().toString().trim();
                    String translate = null;
                    if (!requested.isEmpty()) {
                        String first = requested.split("[,\\s]+")[0];
                        boolean same = chosen.languageCode.equalsIgnoreCase(first)
                                || chosen.languageCode.toLowerCase(Locale.US).startsWith(first.toLowerCase(Locale.US) + "-");
                        if (!same && chosen.translatable) translate = first;
                    }
                    fetchChosenTrack(p, chosen, translate);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void fetchChosenTrack(YouTubeTranscriptClient.Probe p, YouTubeTranscriptClient.Track chosen, String translate) {
        busy("Downloading " + chosen.label() + "…");
        executor.submit(() -> {
            try {
                YouTubeTranscriptClient.Result r = YouTubeTranscriptClient.fetchTrack(p, chosen, translate);
                runOnUiThread(() -> acceptResult(p, r));
            } catch (Exception e) {
                runOnUiThread(() -> fail(e));
            }
        });
    }

    private void acceptResult(YouTubeTranscriptClient.Probe p, YouTubeTranscriptClient.Result r) {
        currentProbe = p;
        lastResult = r;
        searchOffset = -1;
        TranscriptStore.save(this, r);
        render();
        setBusy(false);

        resultTitle.setText(safeTitle(r));
        String mode = r.sourceMethod != null && r.sourceMethod.startsWith("youtube-transcript-io")
                ? "Full transcript"
                : (r.generated ? "Auto-generated captions" : "Manual captions");
        String translated = r.translated ? " • translated to " + r.languageCode : "";
        resultMeta.setText(r.languageName + " [" + r.languageCode + "] • " + mode + translated + " • " + r.segments.size() + " segments");
        status.setVisibility(View.GONE);
        resultSection.setVisibility(View.VISIBLE);
        resultSection.post(() -> pageScroll.smoothScrollTo(0, resultSection.getTop()));
    }

    private void fail(Exception e) {
        setBusy(false);
        status.setVisibility(View.VISIBLE);
        status.setTextColor(Color.rgb(190, 45, 64));
        status.setText("Couldn’t extract this transcript: " +
                (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
    }

    private void busy(String message) {
        setBusy(true);
        status.setVisibility(View.VISIBLE);
        status.setTextColor(Color.rgb(120, 124, 133));
        status.setText(message);
    }

    private void setBusy(boolean busy) {
        fetch.setEnabled(!busy && !bulkRunning);
        fetch.setAlpha((busy || bulkRunning) ? 0.65f : 1f);
        fetch.setText(busy ? "Extracting…" : "Extract transcript");
        if (bulkStart != null && !bulkRunning) {
            bulkStart.setEnabled(!busy);
            bulkStart.setAlpha(busy ? 0.65f : 1f);
        }
    }

    private void render() {
        if (lastResult == null || output == null) return;
        if (timestamps.isChecked()) renderTimestamped();
        else output.setText(lastResult.plainText());
        searchOffset = -1;
    }

    private void renderTimestamped() {
        SpannableStringBuilder b = new SpannableStringBuilder();
        for (YouTubeTranscriptClient.Segment s : lastResult.segments) {
            int start = b.length();
            String stamp = "[" + YouTubeTranscriptClient.shortTime(s.startMs) + "]";
            b.append(stamp);
            final long target = s.startMs;
            b.setSpan(new ClickableSpan() {
                @Override public void onClick(View widget) { openVideoAt(target); }
                @Override public void updateDrawState(TextPaint ds) {
                    ds.setColor(PINK);
                    ds.setUnderlineText(false);
                    ds.setFakeBoldText(true);
                }
            }, start, start + stamp.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            b.append(' ').append(s.text.trim()).append('\n');
        }
        output.setText(b);
    }

    private void findNext() {
        if (lastResult == null) return;
        String q = search.getText().toString();
        if (q.trim().isEmpty()) {
            toast("Type something to search.");
            return;
        }

        int previousOffset = searchOffset;
        if (timestamps.isChecked()) renderTimestamped();
        else output.setText(lastResult.plainText());
        String bodyText = output.getText().toString();
        String lower = bodyText.toLowerCase(Locale.US);
        String needle = q.toLowerCase(Locale.US);
        int from = Math.max(0, previousOffset + 1);
        int found = lower.indexOf(needle, from);
        if (found < 0 && from > 0) found = lower.indexOf(needle);
        if (found < 0) {
            toast("No match.");
            return;
        }
        searchOffset = found;

        SpannableStringBuilder marked = new SpannableStringBuilder(output.getText());
        BackgroundColorSpan span = new BackgroundColorSpan(Color.rgb(255, 218, 228));
        marked.setSpan(span, found, Math.min(found + q.length(), marked.length()), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        output.setText(marked);
        output.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());

        final int targetOffset = found;
        output.post(() -> {
            if (output.getLayout() != null) {
                int line = output.getLayout().getLineForOffset(targetOffset);
                outputScroll.smoothScrollTo(0, output.getLayout().getLineTop(line));
            }
        });
    }

    private void copyTranscript() {
        if (lastResult == null) { toast("Extract a transcript first."); return; }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("YouTube transcript", currentDisplayText()));
        toast("Transcript copied.");
    }

    private void shareTranscript() {
        if (lastResult == null) { toast("Extract a transcript first."); return; }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, safeTitle(lastResult));
        send.putExtra(Intent.EXTRA_TEXT, currentDisplayText());
        startActivity(Intent.createChooser(send, "Share transcript"));
    }

    private void showExport() {
        if (lastResult == null) { toast("Extract a transcript first."); return; }
        String[] formats = {"TXT clean", "TXT timestamped", "SRT", "VTT", "CSV", "JSON"};
        new AlertDialog.Builder(this)
                .setTitle("Export transcript")
                .setItems(formats, (dialog, which) -> {
                    String base = lastResult.videoId + "_" + lastResult.languageCode;
                    switch (which) {
                        case 0: saveDocument(base + ".txt", "text/plain", lastResult.plainText()); break;
                        case 1: saveDocument(base + "_timestamps.txt", "text/plain", lastResult.timestampedText()); break;
                        case 2: saveDocument(base + ".srt", "application/x-subrip", lastResult.srt()); break;
                        case 3: saveDocument(base + ".vtt", "text/vtt", lastResult.vtt()); break;
                        case 4: saveDocument(base + ".csv", "text/csv", lastResult.csv()); break;
                        case 5: saveDocument(base + ".json", "application/json", lastResult.json()); break;
                    }
                })
                .show();
    }

    private void saveDocument(String name, String mime, String text) {
        pendingSaveText = text;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(i, SAVE_DOC);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SAVE_DOC && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null || pendingSaveText == null) return;
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                if (os == null) throw new Exception("Could not open destination.");
                os.write(pendingSaveText.getBytes(StandardCharsets.UTF_8));
                os.flush();
                toast("Saved.");
            } catch (Exception e) {
                toast("Save failed: " + e.getMessage());
            }
        }
    }

    private void showHistory() {
        List<TranscriptStore.Entry> entries = TranscriptStore.list(this);
        if (entries.isEmpty()) {
            toast("History is empty.");
            return;
        }
        String[] labels = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) labels[i] = entries.get(i).label();
        new AlertDialog.Builder(this)
                .setTitle("Recent transcripts")
                .setItems(labels, (dialog, which) -> {
                    try {
                        lastResult = TranscriptStore.load(this, entries.get(which));
                        currentProbe = null;
                        input.setText("https://www.youtube.com/watch?v=" + lastResult.videoId);
                        render();
                        resultTitle.setText(safeTitle(lastResult));
                        resultMeta.setText(lastResult.languageName + " [" + lastResult.languageCode + "] • loaded from history");
                        resultSection.setVisibility(View.VISIBLE);
                        resultSection.post(() -> pageScroll.smoothScrollTo(0, resultSection.getTop()));
                    } catch (Exception e) {
                        toast("Could not open saved transcript.");
                    }
                })
                .setNeutralButton("Clear history", (dialog, which) -> {
                    TranscriptStore.clear(this);
                    toast("History cleared.");
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void openVideoAt(long ms) {
        String id = lastResult != null ? lastResult.videoId : YouTubeTranscriptClient.extractVideoId(input.getText().toString());
        if (id == null) {
            toast("No video loaded.");
            return;
        }
        long seconds = Math.max(0, ms / 1000);
        Uri uri = Uri.parse("https://www.youtube.com/watch?v=" + id + (seconds > 0 ? "&t=" + seconds + "s" : ""));
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) {
            toast("No app can open the video.");
        }
    }

    private void clearScreen() {
        lastResult = null;
        currentProbe = null;
        searchOffset = -1;
        input.setText("");
        if (search != null) search.setText("");
        if (output != null) output.setText("");
        resultSection.setVisibility(View.GONE);
        status.setVisibility(View.GONE);
        pageScroll.smoothScrollTo(0, 0);
    }

    private String currentDisplayText() {
        return timestamps.isChecked() ? lastResult.timestampedText() : lastResult.plainText();
    }

    private String safeTitle(YouTubeTranscriptClient.Result r) {
        return r.title == null || r.title.isEmpty() ? r.videoId : r.title;
    }

    private void addSpace(int dp) {
        View v = new View(this);
        page.addView(v, new LinearLayout.LayoutParams(1, dp(dp)));
    }

    private void addResultSpace(int px) {
        View v = new View(this);
        resultSection.addView(v, new LinearLayout.LayoutParams(1, dp(px)));
    }

    private void addHorizontalSpace(LinearLayout row, int px) {
        View v = new View(this);
        row.addView(v, new LinearLayout.LayoutParams(dp(px), 1));
    }

    private LinearLayout.LayoutParams fullWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int x) {
        return Math.round(x * getResources().getDisplayMetrics().density);
    }

    private float dpFloat(float x) {
        return x * getResources().getDisplayMetrics().density;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        bulkStopRequested = true;
        super.onDestroy();
        executor.shutdownNow();
    }
}
