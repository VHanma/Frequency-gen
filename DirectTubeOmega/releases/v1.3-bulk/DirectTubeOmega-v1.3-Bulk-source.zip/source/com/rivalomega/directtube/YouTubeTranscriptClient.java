package com.rivalomega.directtube;

import android.text.Html;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class YouTubeTranscriptClient {

    private static final String WATCH = "https://www.youtube.com/watch?v=";
    private static final String YTI = "https://www.youtube.com/youtubei/v1/";

    // Current widely-used sdkless client. Omitting androidSdkVersion is intentional.
    private static final String ANDROID_CLIENT_VERSION = "20.10.38";
    private static final String ANDROID_UA =
            "com.google.android.youtube/" + ANDROID_CLIENT_VERSION +
            " (Linux; U; Android 11) gzip";

    private static final String WEB_UA =
            "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/140.0 Mobile Safari/537.36";

    private static final String DEFAULT_COOKIE = "CONSENT=YES+cb; SOCS=CAI";

    private static final Pattern ID_ONLY = Pattern.compile("^[A-Za-z0-9_-]{11}$");
    private static final Pattern URL_ID = Pattern.compile(
            "(?:youtu\\.be/|youtube(?:-nocookie)?\\.com/(?:watch\\?(?:[^#]*&)?v=|shorts/|embed/|live/))([A-Za-z0-9_-]{11})",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern API_KEY = Pattern.compile(
            "\\\"INNERTUBE_API_KEY\\\"\\s*:\\s*\\\"([^\\\"]+)\\\""
    );
    private static final Pattern CLIENT_VERSION = Pattern.compile(
            "\\\"INNERTUBE_CLIENT_VERSION\\\"\\s*:\\s*\\\"([^\\\"]+)\\\""
    );
    private static final Pattern VISITOR_DATA = Pattern.compile(
            "\\\"VISITOR_DATA\\\"\\s*:\\s*\\\"([^\\\"]+)\\\""
    );

    private YouTubeTranscriptClient() {}

    public static final class Segment {
        public final String text;
        public final long startMs;
        public final long durationMs;

        Segment(String text, long startMs, long durationMs) {
            this.text = text;
            this.startMs = Math.max(0, startMs);
            this.durationMs = Math.max(0, durationMs);
        }
    }

    public static final class Track {
        public final String languageCode;
        public final String languageName;
        public final boolean generated;
        public final boolean translatable;
        public final String baseUrl;

        Track(String languageCode, String languageName, boolean generated,
              boolean translatable, String baseUrl) {
            this.languageCode = languageCode;
            this.languageName = languageName;
            this.generated = generated;
            this.translatable = translatable;
            this.baseUrl = baseUrl;
        }

        public String label() {
            return languageCode + " • " + languageName + (generated ? " • auto" : " • manual");
        }
    }

    public static final class Result {
        public String videoId;
        public String title = "";
        public String author = "";
        public String languageCode = "";
        public String languageName = "";
        public boolean generated;
        public boolean translated;
        public String sourceMethod = "";
        public final List<String> availableLanguages = new ArrayList<>();
        public final List<Segment> segments = new ArrayList<>();

        public String plainText() {
            StringBuilder out = new StringBuilder();
            for (Segment s : segments) {
                if (out.length() > 0) out.append(' ');
                out.append(s.text.trim());
            }
            return out.toString().replaceAll("\\s{2,}", " ").trim();
        }

        public String timestampedText() {
            StringBuilder out = new StringBuilder();
            for (Segment s : segments) {
                out.append('[').append(shortTime(s.startMs)).append("] ")
                        .append(s.text.trim()).append('\n');
            }
            return out.toString().trim();
        }

        public String srt() {
            StringBuilder out = new StringBuilder();
            int i = 1;
            for (Segment s : normalizedDurations(segments)) {
                long end = s.startMs + Math.max(1, s.durationMs);
                out.append(i++).append('\n')
                        .append(srtTime(s.startMs)).append(" --> ").append(srtTime(end)).append('\n')
                        .append(s.text.trim()).append("\n\n");
            }
            return out.toString();
        }

        public String vtt() {
            StringBuilder out = new StringBuilder("WEBVTT\n\n");
            for (Segment s : normalizedDurations(segments)) {
                long end = s.startMs + Math.max(1, s.durationMs);
                out.append(vttTime(s.startMs)).append(" --> ").append(vttTime(end)).append('\n')
                        .append(s.text.trim()).append("\n\n");
            }
            return out.toString();
        }

        public String csv() {
            StringBuilder out = new StringBuilder("start_ms,duration_ms,start_time,text\n");
            for (Segment s : normalizedDurations(segments)) {
                out.append(s.startMs).append(',')
                        .append(s.durationMs).append(',')
                        .append(csvEscape(shortTime(s.startMs))).append(',')
                        .append(csvEscape(s.text)).append('\n');
            }
            return out.toString();
        }

        public String markdown() {
            StringBuilder out = new StringBuilder();
            if (!title.isEmpty()) out.append("# ").append(title).append("\n\n");
            out.append("YouTube: https://www.youtube.com/watch?v=").append(videoId).append("\n\n");
            for (Segment s : segments) {
                out.append("**[").append(shortTime(s.startMs)).append("]** ")
                        .append(s.text.trim()).append("\n\n");
            }
            return out.toString();
        }

        public String json() {
            try {
                JSONObject root = new JSONObject();
                root.put("videoId", videoId);
                root.put("title", title);
                root.put("author", author);
                root.put("languageCode", languageCode);
                root.put("languageName", languageName);
                root.put("generated", generated);
                root.put("translated", translated);
                root.put("sourceMethod", sourceMethod);
                root.put("availableLanguages", new JSONArray(availableLanguages));

                JSONArray a = new JSONArray();
                for (Segment s : normalizedDurations(segments)) {
                    JSONObject x = new JSONObject();
                    x.put("text", s.text);
                    x.put("startMs", s.startMs);
                    x.put("durationMs", s.durationMs);
                    a.put(x);
                }
                root.put("segments", a);
                return root.toString(2);
            } catch (JSONException e) {
                return "{}";
            }
        }

        public static Result fromJson(String raw) throws JSONException {
            JSONObject root = new JSONObject(raw);
            Result r = new Result();
            r.videoId = root.optString("videoId", "");
            r.title = root.optString("title", "");
            r.author = root.optString("author", "");
            r.languageCode = root.optString("languageCode", "");
            r.languageName = root.optString("languageName", "");
            r.generated = root.optBoolean("generated", false);
            r.translated = root.optBoolean("translated", false);
            r.sourceMethod = root.optString("sourceMethod", "saved");
            JSONArray langs = root.optJSONArray("availableLanguages");
            if (langs != null) {
                for (int i = 0; i < langs.length(); i++) r.availableLanguages.add(langs.optString(i));
            }
            JSONArray a = root.optJSONArray("segments");
            if (a != null) {
                for (int i = 0; i < a.length(); i++) {
                    JSONObject x = a.optJSONObject(i);
                    if (x != null) {
                        r.segments.add(new Segment(
                                x.optString("text", ""),
                                x.optLong("startMs", 0),
                                x.optLong("durationMs", 0)
                        ));
                    }
                }
            }
            return r;
        }
    }

    public static final class Probe {
        public String videoId;
        public String title = "";
        public String author = "";
        public String sourceMethod = "";
        public final List<Track> tracks = new ArrayList<>();
        private WatchState watch;
        private JSONObject player;
    }

    public static Probe probe(String urlOrId) throws Exception {
        String videoId = extractVideoId(urlOrId);
        if (videoId == null) throw new Exception("Could not find an 11-character YouTube video ID.");

        WatchState watch = loadWatchState(videoId);
        JSONObject player = null;
        String method = "";

        try {
            JSONObject client = new JSONObject();
            client.put("hl", "en");
            client.put("gl", "US");
            client.put("clientName", "ANDROID");
            client.put("clientVersion", ANDROID_CLIENT_VERSION);
            client.put("osName", "Android");
            client.put("osVersion", "11");
            client.put("userAgent", ANDROID_UA);

            JSONObject context = new JSONObject();
            context.put("client", client);

            JSONObject payload = new JSONObject();
            payload.put("context", context);
            payload.put("videoId", videoId);
            payload.put("contentCheckOk", true);
            payload.put("racyCheckOk", true);

            HttpResponse r = postJson(
                    YTI + "player?key=" + enc(watch.apiKey) + "&prettyPrint=false",
                    payload.toString(), ANDROID_UA, watch.cookie,
                    headers("X-YouTube-Client-Name", "3", "X-YouTube-Client-Version", ANDROID_CLIENT_VERSION)
            );
            if (r.code >= 200 && r.code < 300) {
                JSONObject candidate = new JSONObject(r.body);
                if (!parseTracks(candidate).isEmpty()) {
                    player = candidate;
                    method = "innertube-android-sdkless";
                }
            }
        } catch (Exception ignored) {}

        if (player == null && watch.player != null && !parseTracks(watch.player).isEmpty()) {
            player = watch.player;
            method = "watch-page-caption-track";
        }
        if (player == null) throw new Exception("No selectable caption tracks were exposed by YouTube.");

        Probe p = new Probe();
        p.videoId = videoId;
        p.watch = watch;
        p.player = player;
        p.sourceMethod = method;
        JSONObject vd = player.optJSONObject("videoDetails");
        if (vd != null) {
            p.title = vd.optString("title", "");
            p.author = vd.optString("author", "");
        }
        p.tracks.addAll(parseTracks(player));
        return p;
    }

    public static Result fetchTrack(Probe p, Track track, String translateTo) throws Exception {
        if (p == null || track == null || p.watch == null) throw new Exception("Missing transcript track.");
        TrackChoice choice = new TrackChoice();
        choice.track = track;
        if (translateTo != null && !translateTo.trim().isEmpty()
                && !languageMatches(track.languageCode, translateTo.trim())) {
            if (!track.translatable) throw new Exception("This track does not support YouTube translation.");
            choice.translationCode = translateTo.trim();
            choice.translated = true;
        }
        if (track.baseUrl.contains("exp=xpe")) {
            throw new Exception("This track requires a Player/Subtitle PoToken in this session.");
        }
        List<Segment> segs = fetchCaptionUrl(track.baseUrl, choice.translationCode, p.watch.cookie);
        if (segs.isEmpty()) throw new Exception("The selected caption track returned no transcript text.");
        Result out = resultFrom(p.videoId, p.player, choice, p.tracks, segs, p.sourceMethod);
        if (out.title.isEmpty()) out.title = p.title;
        if (out.author.isEmpty()) out.author = p.author;
        return out;
    }

    public static Result fetch(String urlOrId, String preferredLanguages) throws Exception {
        String videoId = extractVideoId(urlOrId);
        if (videoId == null) throw new Exception("Could not find an 11-character YouTube video ID.");

        // Route 0: mirror the current youtube-transcript.io browser path. This is
        // intentionally first because that route is our completeness benchmark.
        try {
            Result r = SiteTranscriptCompat.fetch(videoId, preferredLanguages);
            if (r != null && !r.segments.isEmpty()) return r;
        } catch (Exception ignored) {
            // Keep the app useful if the hosted site changes or is temporarily unavailable.
        }

        String[] prefs = splitLanguages(preferredLanguages);
        WatchState watch = loadWatchState(videoId);

        // Direct fallback 1: Android player caption track.
        try {
            Result r = fetchViaAndroidCaptionTrack(videoId, prefs, watch);
            if (!r.segments.isEmpty()) return r;
        } catch (Exception ignored) {}

        // Direct fallback 2: YouTube transcript panel.
        try {
            Result r = fetchViaTranscriptPanel(videoId, watch);
            if (!r.segments.isEmpty()) return r;
        } catch (Exception ignored) {}

        // Direct fallback 3: watch-page tracks.
        try {
            Result r = fetchViaWatchPlayerTracks(videoId, prefs, watch);
            if (!r.segments.isEmpty()) return r;
        } catch (Exception ignored) {}

        if (watch.player != null) {
            JSONObject ps = watch.player.optJSONObject("playabilityStatus");
            if (ps != null && !"OK".equals(ps.optString("status", "OK"))) {
                String reason = ps.optString("reason", ps.optString("status", "Unavailable"));
                throw new Exception("Video is not playable: " + reason);
            }
        }
        throw new Exception("No usable transcript was exposed for this video.");
    }

    public static String extractVideoId(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (ID_ONLY.matcher(s).matches()) return s;

        Matcher m = URL_ID.matcher(s);
        if (m.find()) return m.group(1);

        Matcher q = Pattern.compile("(?:^|[?&])v=([A-Za-z0-9_-]{11})(?:[&#]|$)").matcher(s);
        if (q.find()) return q.group(1);

        // Shared text often contains prose + a URL.
        Matcher loose = Pattern.compile("(?:v=|youtu\\.be/|shorts/)([A-Za-z0-9_-]{11})").matcher(s);
        if (loose.find()) return loose.group(1);
        return null;
    }

    private static final class WatchState {
        String html;
        String apiKey;
        String clientVersion;
        String visitorData;
        JSONObject player;
        JSONObject initialData;
        String cookie;
    }

    private static WatchState loadWatchState(String videoId) throws Exception {
        WatchState w = new WatchState();
        w.cookie = DEFAULT_COOKIE;
        HttpResponse r = get(WATCH + videoId + "&hl=en", WEB_UA, w.cookie, null);
        if (r.code == 429) throw new Exception("YouTube rate-limited this connection (HTTP 429).");
        if (r.code < 200 || r.code >= 400) throw new Exception("Watch page returned HTTP " + r.code + ".");

        w.html = r.body;
        w.apiKey = firstGroup(API_KEY, w.html);
        w.clientVersion = firstGroup(CLIENT_VERSION, w.html);
        w.visitorData = firstGroup(VISITOR_DATA, w.html);
        w.player = extractAssignedJson(w.html, "ytInitialPlayerResponse");
        w.initialData = extractAssignedJson(w.html, "ytInitialData");

        if (w.apiKey == null || w.apiKey.isEmpty()) {
            throw new Exception("YouTube InnerTube key was not present on the watch page.");
        }
        if (w.clientVersion == null || w.clientVersion.isEmpty()) {
            w.clientVersion = "2.20260114.08.00";
        }
        return w;
    }

    private static Result fetchViaAndroidCaptionTrack(String videoId, String[] prefs, WatchState watch)
            throws Exception {
        JSONObject client = new JSONObject();
        client.put("hl", "en");
        client.put("gl", "US");
        client.put("clientName", "ANDROID");
        client.put("clientVersion", ANDROID_CLIENT_VERSION);
        client.put("osName", "Android");
        client.put("osVersion", "11");
        client.put("userAgent", ANDROID_UA);
        // Do not add androidSdkVersion: this is the sdkless variant.

        JSONObject context = new JSONObject();
        context.put("client", client);

        JSONObject payload = new JSONObject();
        payload.put("context", context);
        payload.put("videoId", videoId);
        payload.put("contentCheckOk", true);
        payload.put("racyCheckOk", true);

        HttpResponse r = postJson(
                YTI + "player?key=" + enc(watch.apiKey) + "&prettyPrint=false",
                payload.toString(), ANDROID_UA, watch.cookie,
                headers("X-YouTube-Client-Name", "3", "X-YouTube-Client-Version", ANDROID_CLIENT_VERSION)
        );
        if (r.code == 429) throw new Exception("YouTube rate-limited the Android player route.");
        if (r.code < 200 || r.code >= 300) throw new Exception("Android player route returned HTTP " + r.code + ".");

        JSONObject player = new JSONObject(r.body);
        List<Track> tracks = parseTracks(player);
        if (tracks.isEmpty()) throw new Exception("Android player returned no caption tracks.");

        TrackChoice choice = chooseTrack(tracks, prefs);
        if (choice.track == null) throw new Exception("No caption track matched.");

        List<Segment> segs = fetchCaptionUrl(choice.track.baseUrl, choice.translationCode, watch.cookie);
        if (segs.isEmpty()) throw new Exception("Android caption track was empty.");

        return resultFrom(videoId, player, choice, tracks, segs, "innertube-android-sdkless");
    }

    private static Result fetchViaWatchPlayerTracks(String videoId, String[] prefs, WatchState watch)
            throws Exception {
        if (watch.player == null) throw new Exception("Watch page had no player response.");
        List<Track> tracks = parseTracks(watch.player);
        if (tracks.isEmpty()) throw new Exception("Watch page had no caption tracks.");

        TrackChoice choice = chooseTrack(tracks, prefs);
        if (choice.track == null) throw new Exception("No caption track matched.");
        if (choice.track.baseUrl.contains("exp=xpe")) {
            throw new Exception("Watch-page caption URL requires a PoToken.");
        }

        List<Segment> segs = fetchCaptionUrl(choice.track.baseUrl, choice.translationCode, watch.cookie);
        if (segs.isEmpty()) throw new Exception("Watch-page caption track was empty.");
        return resultFrom(videoId, watch.player, choice, tracks, segs, "watch-page-caption-track");
    }

    private static Result fetchViaTranscriptPanel(String videoId, WatchState watch) throws Exception {
        JSONObject context = buildWebContext(watch);
        String params = findTranscriptParams(watch.initialData);

        if (params == null || params.isEmpty()) {
            JSONObject nextPayload = new JSONObject();
            nextPayload.put("context", context);
            nextPayload.put("videoId", videoId);
            nextPayload.put("contentCheckOk", true);
            nextPayload.put("racyCheckOk", true);

            HttpResponse next = postJson(
                    YTI + "next?key=" + enc(watch.apiKey) + "&prettyPrint=false",
                    nextPayload.toString(), WEB_UA, watch.cookie, webHeaders(watch)
            );
            if (next.code >= 200 && next.code < 300 && next.body.trim().startsWith("{")) {
                params = findTranscriptParams(new JSONObject(next.body));
            }
        }

        if (params == null || params.isEmpty()) throw new Exception("Transcript panel params not found.");

        JSONObject payload = new JSONObject();
        payload.put("context", context);
        payload.put("params", params);

        HttpResponse tr = postJson(
                YTI + "get_transcript?key=" + enc(watch.apiKey) + "&prettyPrint=false",
                payload.toString(), WEB_UA, watch.cookie, webHeaders(watch)
        );
        if (tr.code == 429) throw new Exception("YouTube rate-limited transcript-panel retrieval.");
        if (tr.code < 200 || tr.code >= 300) throw new Exception("Transcript panel returned HTTP " + tr.code + ".");

        JSONObject root = new JSONObject(tr.body);
        List<Segment> segs = parseTranscriptPanelSegments(root);
        if (segs.isEmpty()) throw new Exception("Transcript panel returned no segments.");

        Result out = new Result();
        out.videoId = videoId;
        fillMetadata(out, watch.player);
        out.languageCode = "panel";
        out.languageName = "YouTube transcript panel";
        out.generated = false;
        out.translated = false;
        out.sourceMethod = "innertube-get-transcript";
        out.segments.addAll(cleanSegments(segs));
        return out;
    }

    private static JSONObject buildWebContext(WatchState watch) throws Exception {
        JSONObject client = new JSONObject();
        client.put("hl", "en");
        client.put("gl", "US");
        client.put("clientName", "WEB");
        client.put("clientVersion", watch.clientVersion);
        client.put("userAgent", WEB_UA);
        if (watch.visitorData != null && !watch.visitorData.isEmpty()) {
            client.put("visitorData", watch.visitorData);
        }

        JSONObject context = new JSONObject();
        context.put("client", client);
        JSONObject user = new JSONObject();
        user.put("lockedSafetyMode", false);
        context.put("user", user);
        JSONObject request = new JSONObject();
        request.put("useSsl", true);
        context.put("request", request);
        return context;
    }

    private static java.util.Map<String, String> webHeaders(WatchState watch) {
        java.util.Map<String, String> h = headers(
                "X-YouTube-Client-Name", "1",
                "X-YouTube-Client-Version", watch.clientVersion,
                "Origin", "https://www.youtube.com",
                "Referer", "https://www.youtube.com/"
        );
        if (watch.visitorData != null && !watch.visitorData.isEmpty()) {
            h.put("X-Goog-Visitor-Id", watch.visitorData);
        }
        return h;
    }

    private static String findTranscriptParams(JSONObject root) {
        if (root == null) return null;
        return findTranscriptParamsAny(root);
    }

    private static String findTranscriptParamsAny(Object node) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject endpoint = o.optJSONObject("getTranscriptEndpoint");
            if (endpoint != null) {
                String p = endpoint.optString("params", "");
                if (!p.isEmpty()) return p;
            }
            JSONArray names = o.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    String key = names.optString(i);
                    Object child = o.opt(key);
                    String p = findTranscriptParamsAny(child);
                    if (p != null) return p;
                }
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) {
                String p = findTranscriptParamsAny(a.opt(i));
                if (p != null) return p;
            }
        }
        return null;
    }

    private static List<Segment> parseTranscriptPanelSegments(JSONObject root) {
        List<Segment> out = new ArrayList<>();
        collectTranscriptSegments(root, out);
        Collections.sort(out, Comparator.comparingLong(s -> s.startMs));

        // Fill missing durations from the next segment.
        List<Segment> normalized = new ArrayList<>();
        for (int i = 0; i < out.size(); i++) {
            Segment s = out.get(i);
            long dur = s.durationMs;
            if (dur <= 0 && i + 1 < out.size()) dur = Math.max(1, out.get(i + 1).startMs - s.startMs);
            if (dur <= 0) dur = 2000;
            normalized.add(new Segment(s.text, s.startMs, dur));
        }
        return normalized;
    }

    private static void collectTranscriptSegments(Object node, List<Segment> out) {
        if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            JSONObject r = o.optJSONObject("transcriptSegmentRenderer");
            if (r != null) {
                String text = textFromRunsOrSimple(r.optJSONObject("snippet"));
                text = cleanText(text);
                long start = safeLong(r.optString("startMs", "0"));
                long end = safeLong(r.optString("endMs", "0"));
                if (!text.isEmpty()) out.add(new Segment(text, start, end > start ? end - start : 0));
                return;
            }
            JSONArray names = o.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) collectTranscriptSegments(o.opt(names.optString(i)), out);
            }
        } else if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length(); i++) collectTranscriptSegments(a.opt(i), out);
        }
    }

    private static List<Track> parseTracks(JSONObject player) {
        List<Track> out = new ArrayList<>();
        if (player == null) return out;
        JSONObject captions = player.optJSONObject("captions");
        if (captions == null) return out;
        JSONObject renderer = captions.optJSONObject("playerCaptionsTracklistRenderer");
        if (renderer == null) return out;
        JSONArray tracks = renderer.optJSONArray("captionTracks");
        if (tracks == null) return out;

        for (int i = 0; i < tracks.length(); i++) {
            JSONObject x = tracks.optJSONObject(i);
            if (x == null) continue;
            String code = x.optString("languageCode", "");
            String base = x.optString("baseUrl", "");
            if (code.isEmpty() || base.isEmpty()) continue;
            String name = textFromRunsOrSimple(x.optJSONObject("name"));
            if (name.isEmpty()) name = code;
            out.add(new Track(code, name, "asr".equals(x.optString("kind")),
                    x.optBoolean("isTranslatable", false), base));
        }
        return out;
    }

    private static final class TrackChoice {
        Track track;
        String translationCode;
        boolean translated;
    }

    private static TrackChoice chooseTrack(List<Track> tracks, String[] prefs) {
        TrackChoice c = new TrackChoice();

        for (String pref : prefs) {
            for (Track t : tracks) {
                if (!t.generated && languageMatches(t.languageCode, pref)) {
                    c.track = t;
                    return c;
                }
            }
            for (Track t : tracks) {
                if (t.generated && languageMatches(t.languageCode, pref)) {
                    c.track = t;
                    return c;
                }
            }
        }

        Track fallback = null;
        for (Track t : tracks) if (!t.generated) { fallback = t; break; }
        if (fallback == null && !tracks.isEmpty()) fallback = tracks.get(0);
        c.track = fallback;

        if (fallback != null && fallback.translatable && prefs.length > 0
                && !languageMatches(fallback.languageCode, prefs[0])) {
            c.translationCode = prefs[0];
            c.translated = true;
        }
        return c;
    }

    private static List<Segment> fetchCaptionUrl(String baseUrl, String translationCode, String cookie)
            throws Exception {
        String url = baseUrl.replace("&fmt=srv3", "").replace("&fmt=srv1", "");
        if (translationCode != null && !translationCode.isEmpty()) {
            url += (url.contains("?") ? "&" : "?") + "tlang=" + enc(translationCode);
        }

        String jsonUrl = url + (url.contains("?") ? "&" : "?") + "fmt=json3";
        HttpResponse jr = get(jsonUrl, WEB_UA, cookie, null);
        if (jr.code == 429) throw new Exception("YouTube rate-limited caption download.");
        if (jr.code >= 200 && jr.code < 300 && jr.body.trim().startsWith("{")) {
            List<Segment> parsed = parseJson3(jr.body);
            if (!parsed.isEmpty()) return cleanSegments(parsed);
        }

        HttpResponse xr = get(url, WEB_UA, cookie, null);
        if (xr.code >= 200 && xr.code < 300 && xr.bytes.length > 0) {
            List<Segment> parsed = parseXml(xr.bytes);
            if (!parsed.isEmpty()) return cleanSegments(parsed);
        }
        return new ArrayList<>();
    }

    private static Result resultFrom(String videoId, JSONObject player, TrackChoice choice,
                                     List<Track> tracks, List<Segment> segs, String method) {
        Result out = new Result();
        out.videoId = videoId;
        fillMetadata(out, player);
        out.languageCode = choice.translated && choice.translationCode != null
                ? choice.translationCode : choice.track.languageCode;
        out.languageName = choice.track.languageName;
        out.generated = choice.track.generated;
        out.translated = choice.translated;
        out.sourceMethod = method;
        out.segments.addAll(segs);
        Set<String> seen = new LinkedHashSet<>();
        for (Track t : tracks) {
            String label = t.languageCode + " — " + t.languageName + (t.generated ? " (auto)" : " (manual)");
            if (seen.add(label)) out.availableLanguages.add(label);
        }
        return out;
    }

    private static void fillMetadata(Result out, JSONObject player) {
        if (player == null) return;
        JSONObject vd = player.optJSONObject("videoDetails");
        if (vd != null) {
            out.title = vd.optString("title", "");
            out.author = vd.optString("author", "");
        }
    }

    private static List<Segment> parseJson3(String raw) throws Exception {
        List<Segment> out = new ArrayList<>();
        JSONObject root = new JSONObject(raw);
        JSONArray events = root.optJSONArray("events");
        if (events == null) return out;

        for (int i = 0; i < events.length(); i++) {
            JSONObject e = events.optJSONObject(i);
            if (e == null) continue;
            JSONArray segs = e.optJSONArray("segs");
            if (segs == null) continue;
            StringBuilder text = new StringBuilder();
            for (int j = 0; j < segs.length(); j++) {
                JSONObject s = segs.optJSONObject(j);
                if (s != null) text.append(s.optString("utf8", ""));
            }
            String cleaned = cleanText(text.toString());
            if (cleaned.isEmpty()) continue;
            out.add(new Segment(cleaned, e.optLong("tStartMs", 0), e.optLong("dDurationMs", 0)));
        }
        return out;
    }

    private static List<Segment> parseXml(byte[] bytes) throws Exception {
        List<Segment> out = new ArrayList<>();
        XmlPullParserFactory f = XmlPullParserFactory.newInstance();
        f.setNamespaceAware(false);
        XmlPullParser p = f.newPullParser();
        p.setInput(new ByteArrayInputStream(bytes), "UTF-8");

        int event = p.getEventType();
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                String tag = p.getName();
                if ("text".equals(tag)) {
                    long start = secondsToMs(p.getAttributeValue(null, "start"));
                    long dur = secondsToMs(p.getAttributeValue(null, "dur"));
                    String text = cleanText(p.nextText());
                    if (!text.isEmpty()) out.add(new Segment(text, start, dur));
                } else if ("p".equals(tag)) {
                    long start = safeLong(p.getAttributeValue(null, "t"));
                    long dur = safeLong(p.getAttributeValue(null, "d"));
                    String text = cleanText(p.nextText());
                    if (!text.isEmpty()) out.add(new Segment(text, start, dur));
                }
            }
            event = p.next();
        }
        return out;
    }

    private static List<Segment> cleanSegments(List<Segment> input) {
        List<Segment> out = new ArrayList<>();
        String previous = null;
        for (Segment s : input) {
            String text = cleanText(s.text);
            if (text.isEmpty()) continue;
            if (previous != null && text.equals(previous)) continue;
            out.add(new Segment(text, s.startMs, s.durationMs));
            previous = text;
        }
        return out;
    }

    private static List<Segment> normalizedDurations(List<Segment> src) {
        List<Segment> out = new ArrayList<>();
        for (int i = 0; i < src.size(); i++) {
            Segment s = src.get(i);
            long dur = s.durationMs;
            if (dur <= 0 && i + 1 < src.size()) dur = Math.max(1, src.get(i + 1).startMs - s.startMs);
            if (dur <= 0) dur = 2000;
            out.add(new Segment(s.text, s.startMs, dur));
        }
        return out;
    }

    private static String[] splitLanguages(String raw) {
        if (raw == null || raw.trim().isEmpty()) return new String[]{"en"};
        String[] parts = raw.split("[,\\s]+");
        List<String> clean = new ArrayList<>();
        for (String p : parts) if (!p.trim().isEmpty()) clean.add(p.trim());
        return clean.isEmpty() ? new String[]{"en"} : clean.toArray(new String[0]);
    }

    private static boolean languageMatches(String track, String wanted) {
        if (track == null || wanted == null) return false;
        String a = track.toLowerCase(Locale.US);
        String b = wanted.trim().toLowerCase(Locale.US);
        return a.equals(b) || a.startsWith(b + "-") || b.startsWith(a + "-");
    }

    private static String cleanText(String s) {
        if (s == null) return "";
        String x = Build.VERSION.SDK_INT >= 24
                ? Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString()
                : Html.fromHtml(s).toString();
        return x.replace('\u00A0', ' ').replace("\r", " ").replace("\n", " ")
                .replaceAll("\\s{2,}", " ").trim();
    }

    private static JSONObject extractAssignedJson(String html, String name) {
        if (html == null) return null;
        int from = 0;
        while (true) {
            int idx = html.indexOf(name, from);
            if (idx < 0) return null;
            int brace = html.indexOf('{', idx + name.length());
            if (brace < 0) return null;
            String raw = extractBalancedObject(html, brace);
            if (raw != null) {
                try { return new JSONObject(raw); } catch (Exception ignored) {}
            }
            from = idx + name.length();
        }
    }

    private static String extractBalancedObject(String s, int start) {
        int depth = 0;
        boolean inString = false;
        boolean escape = false;
        for (int i = start; i < s.length(); i++) {
            char c = s.charAt(i);
            if (inString) {
                if (escape) escape = false;
                else if (c == '\\') escape = true;
                else if (c == '"') inString = false;
                continue;
            }
            if (c == '"') inString = true;
            else if (c == '{') depth++;
            else if (c == '}') {
                depth--;
                if (depth == 0) return s.substring(start, i + 1);
            }
        }
        return null;
    }

    private static String textFromRunsOrSimple(JSONObject obj) {
        if (obj == null) return "";
        String simple = obj.optString("simpleText", "");
        if (!simple.isEmpty()) return simple;
        JSONArray runs = obj.optJSONArray("runs");
        if (runs == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < runs.length(); i++) {
            JSONObject r = runs.optJSONObject(i);
            if (r != null) b.append(r.optString("text", ""));
        }
        return b.toString();
    }

    private static String firstGroup(Pattern p, String s) {
        Matcher m = p.matcher(s == null ? "" : s);
        return m.find() ? m.group(1) : null;
    }

    private static String enc(String s) throws Exception {
        return URLEncoder.encode(s == null ? "" : s, "UTF-8");
    }

    private static long secondsToMs(String s) {
        try { return Math.round(Double.parseDouble(s) * 1000.0); }
        catch (Exception e) { return 0; }
    }

    private static long safeLong(String s) {
        try { return Long.parseLong(s == null ? "0" : s); }
        catch (Exception e) { return 0; }
    }

    public static String shortTime(long ms) {
        long total = ms / 1000;
        long h = total / 3600;
        long m = (total % 3600) / 60;
        long s = total % 60;
        return h > 0 ? String.format(Locale.US, "%d:%02d:%02d", h, m, s)
                : String.format(Locale.US, "%02d:%02d", m, s);
    }

    private static String srtTime(long ms) {
        long h = ms / 3600000, m = (ms % 3600000) / 60000, s = (ms % 60000) / 1000, x = ms % 1000;
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", h, m, s, x);
    }

    private static String vttTime(long ms) {
        long h = ms / 3600000, m = (ms % 3600000) / 60000, s = (ms % 60000) / 1000, x = ms % 1000;
        return String.format(Locale.US, "%02d:%02d:%02d.%03d", h, m, s, x);
    }

    private static String csvEscape(String s) {
        if (s == null) return "\"\"";
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    private static java.util.Map<String, String> headers(String... kv) {
        java.util.Map<String, String> m = new java.util.LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) m.put(kv[i], kv[i + 1]);
        return m;
    }

    private static HttpResponse get(String url, String ua, String cookie, java.util.Map<String, String> extra)
            throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(25000);
        c.setInstanceFollowRedirects(true);
        c.setRequestMethod("GET");
        c.setRequestProperty("User-Agent", ua);
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
        if (cookie != null) c.setRequestProperty("Cookie", cookie);
        if (extra != null) for (java.util.Map.Entry<String, String> e : extra.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
        return readResponse(c);
    }

    private static HttpResponse postJson(String url, String json, String ua, String cookie,
                                         java.util.Map<String, String> extra) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(25000);
        c.setInstanceFollowRedirects(true);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("User-Agent", ua);
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        if (cookie != null) c.setRequestProperty("Cookie", cookie);
        if (extra != null) for (java.util.Map.Entry<String, String> e : extra.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());

        byte[] body = json.getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(body.length);
        try (OutputStream os = c.getOutputStream()) { os.write(body); }
        return readResponse(c);
    }

    private static HttpResponse readResponse(HttpURLConnection c) throws Exception {
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        if (in != null) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            in.close();
        }
        byte[] bytes = out.toByteArray();
        String body = new String(bytes, StandardCharsets.UTF_8);
        c.disconnect();
        return new HttpResponse(code, body, bytes);
    }

    private static final class HttpResponse {
        final int code;
        final String body;
        final byte[] bytes;
        HttpResponse(int code, String body, byte[] bytes) {
            this.code = code;
            this.body = body;
            this.bytes = bytes;
        }
    }
}
